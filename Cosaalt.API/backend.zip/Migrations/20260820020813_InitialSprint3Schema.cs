﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Cosaalt.API.Migrations
{
    /// <inheritdoc />
    public partial class InitialSprint3Schema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MotivoCambioMedidor",
                columns: table => new
                {
                    Id_motivo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Descripcion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Activo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MotivoCambioMedidor", x => x.Id_motivo);
                });

            migrationBuilder.CreateTable(
                name: "Socio",
                columns: table => new
                {
                    Reg_soc = table.Column<int>(type: "int", nullable: false),
                    Catastral_soc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nom_soc = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Direc_soc = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    Cat_soc = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Ruta_soc = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Recorrido_soc = table.Column<int>(type: "int", nullable: true),
                    CI_soc = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Telefono_soc = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Sexo_soc = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Socio", x => x.Reg_soc);
                });

            migrationBuilder.CreateTable(
                name: "SolicitudLectura",
                columns: table => new
                {
                    Nro_hoja_solicitudLec = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Año_mes_solicitudLec = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Fecha_emision_solicitudLec = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Hora_emision_solicitudLec = table.Column<TimeSpan>(type: "time", nullable: true),
                    Elaborad_por_solicitudLec = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Cod_obs_solicitudLec = table.Column<int>(type: "int", nullable: false),
                    Desc_obs_solicitudLec = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SolicitudLectura", x => x.Nro_hoja_solicitudLec);
                });

            migrationBuilder.CreateTable(
                name: "UsuarioApp",
                columns: table => new
                {
                    IdUsuarioApp = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NombreUsuario = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ContrasenaHash = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    NombreCompleto = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Rol = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Activo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuarioApp", x => x.IdUsuarioApp);
                });

            migrationBuilder.CreateTable(
                name: "Medidor",
                columns: table => new
                {
                    Nro_medidor = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Marca_medidor = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Reg_soc = table.Column<int>(type: "int", nullable: false),
                    Fecha_instalacion_medidor = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Estado_medidor = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Latitud_medidor = table.Column<double>(type: "float", nullable: true),
                    Longitud_medidor = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medidor", x => x.Nro_medidor);
                    table.ForeignKey(
                        name: "FK_Medidor_Socio_Reg_soc",
                        column: x => x.Reg_soc,
                        principalTable: "Socio",
                        principalColumn: "Reg_soc",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ReclamoODECO",
                columns: table => new
                {
                    Folio_odeco = table.Column<int>(type: "int", nullable: false),
                    Fecha_rec_odeco = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Reg_soc = table.Column<int>(type: "int", nullable: false),
                    Nombre_sol_odeco = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    CI_sol_odeco = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Telf_sol__odeco = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Tipo_visita_odeco = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Motivo_rec__odeco = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Fecha_est_resp_odeco = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Resp_atc_odeco = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Lect_ant_anali_odeco = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    Lect_act_anali_odeco = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    Consumo_anali_odeco = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: true),
                    Grifos_odeco = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Llave_paso_odeco = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Medidor_parado_odeco = table.Column<bool>(type: "bit", nullable: false),
                    Inspección_odeco = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Diagnostico_odeco = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Comentarios_odeco = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    Tipo_reclamo_odeco = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Fecha_inspeccion_odeco = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Conclusion_odeco = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Prioridad_nota_odeco = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReclamoODECO", x => x.Folio_odeco);
                    table.ForeignKey(
                        name: "FK_ReclamoODECO_Socio_Reg_soc",
                        column: x => x.Reg_soc,
                        principalTable: "Socio",
                        principalColumn: "Reg_soc",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DetalleSolicitudLectura",
                columns: table => new
                {
                    Id_detalle = table.Column<int>(type: "int", nullable: false),
                    Nro_hoja_detalle = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Reg_soc = table.Column<int>(type: "int", nullable: false),
                    Lec_ant_detalle = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Lec_act_detalle = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Consumo_detalle = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DetalleSolicitudLectura", x => x.Id_detalle);
                    table.ForeignKey(
                        name: "FK_DetalleSolicitudLectura_Socio_Reg_soc",
                        column: x => x.Reg_soc,
                        principalTable: "Socio",
                        principalColumn: "Reg_soc",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DetalleSolicitudLectura_SolicitudLectura_Nro_hoja_detalle",
                        column: x => x.Nro_hoja_detalle,
                        principalTable: "SolicitudLectura",
                        principalColumn: "Nro_hoja_solicitudLec",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AsignacionRuta",
                columns: table => new
                {
                    IdAsignacion = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdUsuarioApp = table.Column<int>(type: "int", nullable: false),
                    FechaAsignacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AsignacionRuta", x => x.IdAsignacion);
                    table.ForeignKey(
                        name: "FK_AsignacionRuta_UsuarioApp_IdUsuarioApp",
                        column: x => x.IdUsuarioApp,
                        principalTable: "UsuarioApp",
                        principalColumn: "IdUsuarioApp",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EjecucionCambio",
                columns: table => new
                {
                    IdEjecucion = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TipoOrigen = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IdOrigen = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IdUsuarioApp = table.Column<int>(type: "int", nullable: false),
                    FechaHoraEjecucion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NroMedidorRetirado = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    MarcaRetirado = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LecturaRetiro = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    IdMotivo = table.Column<int>(type: "int", nullable: false),
                    NroMedidorInstalado = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    MarcaInstalado = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Observaciones = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    LatLong = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Sincronizado = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EjecucionCambio", x => x.IdEjecucion);
                    table.ForeignKey(
                        name: "FK_EjecucionCambio_MotivoCambioMedidor_IdMotivo",
                        column: x => x.IdMotivo,
                        principalTable: "MotivoCambioMedidor",
                        principalColumn: "Id_motivo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EjecucionCambio_UsuarioApp_IdUsuarioApp",
                        column: x => x.IdUsuarioApp,
                        principalTable: "UsuarioApp",
                        principalColumn: "IdUsuarioApp",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DetalleRuta",
                columns: table => new
                {
                    IdDetalle = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdAsignacion = table.Column<int>(type: "int", nullable: false),
                    TipoOrigen = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IdOrigen = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    OrdenVisita = table.Column<int>(type: "int", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    SolicitudId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    NombreCliente = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Direccion = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    Latitud = table.Column<double>(type: "float", nullable: true),
                    Longitud = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DetalleRuta", x => x.IdDetalle);
                    table.ForeignKey(
                        name: "FK_DetalleRuta_AsignacionRuta_IdAsignacion",
                        column: x => x.IdAsignacion,
                        principalTable: "AsignacionRuta",
                        principalColumn: "IdAsignacion",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EvidenciaFotografica",
                columns: table => new
                {
                    IdFoto = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdEjecucion = table.Column<int>(type: "int", nullable: false),
                    TipoFoto = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    RutaArchivoServidor = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EvidenciaFotografica", x => x.IdFoto);
                    table.ForeignKey(
                        name: "FK_EvidenciaFotografica_EjecucionCambio_IdEjecucion",
                        column: x => x.IdEjecucion,
                        principalTable: "EjecucionCambio",
                        principalColumn: "IdEjecucion",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AsignacionRuta_IdUsuarioApp",
                table: "AsignacionRuta",
                column: "IdUsuarioApp");

            migrationBuilder.CreateIndex(
                name: "IX_DetalleRuta_IdAsignacion",
                table: "DetalleRuta",
                column: "IdAsignacion");

            migrationBuilder.CreateIndex(
                name: "IX_DetalleSolicitudLectura_Nro_hoja_detalle",
                table: "DetalleSolicitudLectura",
                column: "Nro_hoja_detalle");

            migrationBuilder.CreateIndex(
                name: "IX_DetalleSolicitudLectura_Reg_soc",
                table: "DetalleSolicitudLectura",
                column: "Reg_soc");

            migrationBuilder.CreateIndex(
                name: "IX_EjecucionCambio_IdMotivo",
                table: "EjecucionCambio",
                column: "IdMotivo");

            migrationBuilder.CreateIndex(
                name: "IX_EjecucionCambio_IdUsuarioApp",
                table: "EjecucionCambio",
                column: "IdUsuarioApp");

            migrationBuilder.CreateIndex(
                name: "IX_EvidenciaFotografica_IdEjecucion",
                table: "EvidenciaFotografica",
                column: "IdEjecucion");

            migrationBuilder.CreateIndex(
                name: "UX_Medidor_RegSoc_Activo",
                table: "Medidor",
                column: "Reg_soc",
                unique: true,
                filter: "[Estado_medidor] = N'Activo'");

            migrationBuilder.CreateIndex(
                name: "IX_ReclamoODECO_Reg_soc",
                table: "ReclamoODECO",
                column: "Reg_soc");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DetalleRuta");

            migrationBuilder.DropTable(
                name: "DetalleSolicitudLectura");

            migrationBuilder.DropTable(
                name: "EvidenciaFotografica");

            migrationBuilder.DropTable(
                name: "Medidor");

            migrationBuilder.DropTable(
                name: "ReclamoODECO");

            migrationBuilder.DropTable(
                name: "AsignacionRuta");

            migrationBuilder.DropTable(
                name: "SolicitudLectura");

            migrationBuilder.DropTable(
                name: "EjecucionCambio");

            migrationBuilder.DropTable(
                name: "Socio");

            migrationBuilder.DropTable(
                name: "MotivoCambioMedidor");

            migrationBuilder.DropTable(
                name: "UsuarioApp");
        }
    }
}
